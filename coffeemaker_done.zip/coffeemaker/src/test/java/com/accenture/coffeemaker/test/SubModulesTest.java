package com.accenture.coffeemaker.test;

import com.accenture.coffeemaker.errors.BeanTrayEmptyException;
import com.accenture.coffeemaker.errors.ServeTrayEmptyException;
import com.accenture.coffeemaker.submodules.BeanTray;
import com.accenture.coffeemaker.submodules.ServeTray;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class SubModulesTest {
    @Test
    public void testCheckAvailabilityThrowsExceptionWhenServeTrayIsEmpty() {
        ServeTray serveTray = new ServeTray();

        assertThrows(ServeTrayEmptyException.class, serveTray::checkAvailability);
    }

    @Test
    public void testCheckAvailabilityThrowsExceptionWhenBeanTrayIsEmpty() throws BeanTrayEmptyException {
        BeanTray beanTray = new BeanTray();
        for (int i = 0; i < 10; i++) {
            beanTray.useBean();
        }

        assertThrows(BeanTrayEmptyException.class, beanTray::checkAvailability);
    }
}
