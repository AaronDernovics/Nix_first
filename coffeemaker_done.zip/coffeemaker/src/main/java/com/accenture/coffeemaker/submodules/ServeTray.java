package com.accenture.coffeemaker.submodules;

import com.accenture.coffeemaker.errors.ServeTrayEmptyException;
import lombok.extern.slf4j.Slf4j;

import static com.accenture.coffeemaker.constants.Constants.*;

@Slf4j
public class ServeTray implements CheckAvailability {
    private boolean hasCup;

    public ServeTray() {
        this.hasCup = false;
    }

    public void checkAvailability() throws ServeTrayEmptyException {
        if (!hasCup) {
            throw new ServeTrayEmptyException(NO_CUP);
        }
    }

    public void placeCup() {
        hasCup = true;
        log.info(CUP_PLACED);
    }

    public void removeCup() {
        hasCup = false;
        log.info(CUP_REMOVED);
    }
}
