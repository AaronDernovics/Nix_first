package com.accenture.coffeemaker.errors;

public class ServeTrayEmptyException extends Exception {
    public ServeTrayEmptyException(String message) {
        super(message);
    }
}
