package com.accenture.coffeemaker.submodules;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Display implements CheckAvailability{
    public void displayMessage(String message) {
        log.info("Message: " + message);
    }

    public void checkAvailability() {
        log.info("Display is working");
    }
}
