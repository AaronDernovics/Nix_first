package com.accenture.coffeemaker.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {
    static final public String INPUT_NOT_VALID = "Input not valid";
    static final public String MAKE_COFFEE = "Making coffee...";
    static final public String COFFEE_READY = "Coffee is ready!";
    static final public String TRY_AGAIN = "A new cup has been placed. Please try making coffee again.";
    static final public String NO_CUP = "No cup on the serve tray";
    static final public String CUP_PLACED = "Cup placed on the serve tray.";
    static final public String CUP_REMOVED = "Cup removed from the serve tray.";
    static final public String BEAN_TRAY_EMPTY = "Bean tray is empty. Press 2 to refill the bean tray!";
    static final public String BEAN_TRAY_REFILLED = "Bean tray refilled to 10 cups.";
    static final public String AN_UNEXPECTED_ERROR_OCCURRED = "An unexpected error occurred: ";
}
