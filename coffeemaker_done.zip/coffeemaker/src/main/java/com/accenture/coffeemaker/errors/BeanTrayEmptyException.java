package com.accenture.coffeemaker.errors;

public class BeanTrayEmptyException extends Exception {
    public BeanTrayEmptyException(String message) {
        super(message);
    }
}
