package com.accenture.coffeemaker.submodules;

public interface CheckAvailability {
    void checkAvailability() throws Exception;
}
