package com.accenture.coffeemaker.coffeemachine;

import com.accenture.coffeemaker.errors.BeanTrayEmptyException;
import com.accenture.coffeemaker.errors.ServeTrayEmptyException;
import com.accenture.coffeemaker.submodules.BeanTray;
import com.accenture.coffeemaker.submodules.Display;
import com.accenture.coffeemaker.submodules.ServeTray;

import static com.accenture.coffeemaker.constants.Constants.*;

public class CoffeeMaker {
    private final BeanTray beanTray;
    private final ServeTray serveTray;
    private final Display display;

    public CoffeeMaker() {
        this.beanTray = new BeanTray();
        this.serveTray = new ServeTray();
        this.display = new Display();
    }

    public void makeCoffee() {
        try {
            display.checkAvailability();
            serveTray.checkAvailability();
            beanTray.checkAvailability();

            beanTray.useBean();
            display.displayMessage(MAKE_COFFEE);
            display.displayMessage(COFFEE_READY);

            serveTray.removeCup();
        } catch (BeanTrayEmptyException e) {
            display.displayMessage(e.getMessage());
        } catch (ServeTrayEmptyException e) {
            display.displayMessage(e.getMessage());
            serveTray.placeCup();
            display.displayMessage(TRY_AGAIN);
        } catch (Exception e) {
            display.displayMessage(AN_UNEXPECTED_ERROR_OCCURRED + e.getMessage());
        }
    }

    public void fillBeanTray() {
        beanTray.fillBeans();
    }
}
