package com.accenture.coffeemaker.submodules;

import com.accenture.coffeemaker.errors.BeanTrayEmptyException;
import lombok.extern.slf4j.Slf4j;

import static com.accenture.coffeemaker.constants.Constants.BEAN_TRAY_EMPTY;
import static com.accenture.coffeemaker.constants.Constants.BEAN_TRAY_REFILLED;

@Slf4j
public class BeanTray implements CheckAvailability {
    private Integer beans;

    public BeanTray() {
        this.beans = 10;
    }

    public void checkAvailability() throws BeanTrayEmptyException {
        if (beans <= 0) {
            throw new BeanTrayEmptyException(BEAN_TRAY_EMPTY);
        }
    }

    public void useBean() throws BeanTrayEmptyException {
        checkAvailability();
        beans--;
    }

    public void fillBeans() {
        beans = 10;
        log.info(BEAN_TRAY_REFILLED);
    }
}
